# How to run:

Locate and run the ```Server.bat``` file and to start the game

If ```Server.bat``` doesn't work try opening ```out/build/Debug/``` and there run ```Server.exe```

If you want to log game sessions download XAMPP and copy code from [this link](https://github.com/AveeMaria/finals-website) to htdocs and change the link in ```logger_url.txt```.